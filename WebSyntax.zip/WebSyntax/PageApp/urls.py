from django.urls import path,include
from .views import *


urlpatterns = [
    path("",Home_Page,name='home'),
    path("register/",Register_Page,name='register'),
    path("contact/",Contact_Page,name='contact'), 
    path("logout/",Logout_Page,name='logout'), 
    path("user/",Profile_Page,name='profile'), 
]