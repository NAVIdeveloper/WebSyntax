from ApiApp.models import *
from django.shortcuts import render,redirect
from django.contrib.auth.decorators import login_required
# Create your views here.
import requests
from django.contrib.auth.hashers import make_password
from django.contrib.auth import login,logout
from rest_framework.authtoken.models import Token
from ApiApp.models import *
from ApiApp.splitter.main import Mode

example_code = '''
# Python3 program to find simple interest
# for given principal amount, time and
# rate of interest. 
 
def simple_interest(p,t,r):
    print('The principal is', p)
    print('The time period is', t)
    print('The rate of interest is',r)
     
    si = (p * t * r)/100
     
    print('The Simple Interest is', si)
    return si
    
# Driver code
simple_interest(8, 6, 8)
'''

def Home_Page(request):
	DATA = {
	"modes":[],
	"slider":Slider.objects.last(),
	"styles":9,
	"user":request.user,
	}
	for mode in Style.objects.all():
		DATA['modes'].append({"mode":mode,'code':Mode(example_code,'python',mode)})

	return render(request,"index.html",DATA)

def Register_Page(request):
	if request.user.is_authenticated:
		return redirect('contact')
	if request.method == 'POST':
		status_type = request.POST['type']
		if status_type == 'old':
			username = request.POST['username']
			password = request.POST['password']
			try:
				client = Client.objects.get(username=username)
				if client.check_password(password):
					login(request,client)
					return redirect('profile')
				else:
					return redirect("register")
			except:
				return redirect("register")
		else:
			username = request.POST['username']
			email = request.POST['email']
			password = request.POST['password']
			profesion = request.POST['profesion']
			try:
				user = Client.objects.create(username=username,email=email,profession=profesion)
				user.set_password(password)
				user.save()
				key = Token.objects.create(user=user)
				login(request,user)
				return redirect("profile")
			except Exception as e:
				return redirect('register')

	return render(request,'register.html')

def send_message(chat_id, msg, parse_mode):
	bot_token = "5253218668:AAGHCKiIo0bZNua1A27O1ie5VjsIuT5EKzc"
	url = f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={msg}&parse_mode={parse_mode}"
	requests.get(url)

def Contact_Page(request):
	if request.method == 'POST':
		name = request.POST['name']
		email = request.POST['email']
		subject = request.POST['subject']
		message = request.POST['message']
		contact = ContactUs.objects.create(name=name,email=email,subject=subject,message=message)
		ADMIN_ID = "5252604266"
		send_message(
			ADMIN_ID,
			f"""
<b>{name}</b>\n
<b>{email}</b>\n
<b>{subject}</b>\n
<b>{message}</b>""",
		"HTML"
		)	
		return redirect('home')
	return render(request,'contact.html')

def Logout_Page(request):
	logout(request)
	return redirect("home")

def Profile_Page(request):
	if request.user.is_authenticated:
		if request.method == 'POST':
			ucode = request.POST.get('u')
			if ucode == 'token':
				old_token = Token.objects.get(user=request.user)
				old_token.delete()
				new_token = Token.objects.create(user=request.user)
				return redirect("profile")
			elif ucode == 'img':
				new_img = request.FILES.get('img_file')
				user = Client.objects.get(username=request.user)
				user.img = new_img
				user.save()
				return redirect("profile")
		
		DATA = {
		"user":request.user,
		"token":Token.objects.get(user=request.user),
		}
		return render(request,'profile.html',DATA)
	return redirect("register")
 