from pygments.style import Style
from pygments.token import Keyword, Name, Comment, String, Error, Text, \
     Number, Operator, Generic, Whitespace, Punctuation, Other, Literal
from pygments.lexers import python,html,javascript,c_cpp,css,go,php,data,objective
from pygments.formatters import HtmlFormatter
from pygments import highlight
from pygments.styles import  monokai,abap,algol,arduino,autumn,borland,bw,colorful,default,dracula,emacs,friendly,fruity,gruvbox,igor,inkpot,lilypond,lovelace,manni,material,murphy,native,onedark,paraiso_dark,paraiso_light,pastie,perldoc,rainbow_dash,rrt,solarized,stata_dark,stata_light,vim




def Mode(code:str,lang:str,style):
    style = eval(f"{style.name}.{style.class_name}")
    formatter = HtmlFormatter(style=style,noclasses=True,lineseperator='<br>') 
    if lang == 'python':
        language = python.PythonLexer()
    elif lang == "html":
        language = html.HtmlLexer()
    elif lang == "javascript":
        language = javascript.JavascriptLexer()
    elif lang == 'c++':
        language = c_cpp.CppLexer()
    elif lang == 'css':
        language = css.CssLexer()
    elif lang == 'php':
        language = php.PhpLexer()    
    elif lang == 'json':
       language = data.JsonLexer()
    elif lang == 'c':
        language = objective.CLexer()
    elif lang == 'swift':
        language = objective.SwiftLexer()

    html_code = highlight(code,language,formatter)
	# html_code += f"<style>{formatter.get_style_defs()} {'.highlight {background-color: '+style.background_color + ';}'}</style>"
	
    return html_code
