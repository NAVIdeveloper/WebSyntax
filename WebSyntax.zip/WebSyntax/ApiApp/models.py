from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class Language(models.Model):
    name = models.CharField(max_length=255)
    count_use = models.IntegerField(default=0)
    logo = models.ImageField(upload_to='lang/logo/')
    def __str__(self):
        return self.name

class Client(AbstractUser):
    img = models.ImageField(upload_to='clients/',null=True,blank=True)
    count_use = models.IntegerField(default=0)  
    profession = models.CharField(max_length=60,null=True,blank=True)
    limit = models.IntegerField(default=100)
    
class Slider(models.Model):
    title = models.CharField(max_length=255)
    desc = models.CharField(max_length=255)    
    img = models.ImageField(upload_to='slider/')

    def __str__(self):
        return self.title

class Style(models.Model):
    name = models.CharField(max_length=255)
    class_name = models.CharField(max_length=255)
    star = models.IntegerField(default=0)

    def __str__(self):
        return self.name


class ContactUs(models.Model):
    name = models.CharField(max_length=255)
    email = models.EmailField(max_length=255)
    subject = models.CharField(max_length=255)
    
    message = models.TextField()
   
    def __str__(self):
        return self.subject


class Payment(models.Model):
    user = models.ForeignKey(Client,on_delete=models.CASCADE)
    price = models.IntegerField(default=0)
    date = models.DateField(auto_now=True)
    limit = models.IntegerField(default=0)
    def __str__(self):
        return self.user.username
