from django.urls import path
from .views import *
urlpatterns = [
    path("code/",Api_Code),
    # path("register/",Api_Register),
    # path("login/",Api_Login),
    path("styles/",Api_Style),
    path("languages/",Api_Language),
    path("payments/",View_Payment),
]
