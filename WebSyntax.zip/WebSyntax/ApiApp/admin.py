from django.contrib import admin

# Register your models here.
from .models import *

admin.site.register(Language)
admin.site.register(Client)
admin.site.register(Style)
admin.site.register(Slider)
admin.site.register(ContactUs)
admin.site.register(Payment)
