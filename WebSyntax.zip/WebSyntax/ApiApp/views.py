from django.shortcuts import render
from .splitter.main import Mode
from .loader import *
from .models import *
from rest_framework.response import Response
from rest_framework.decorators import api_view
from rest_framework.authtoken.models import Token
from rest_framework.decorators import authentication_classes,permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.authentication import TokenAuthentication
from pygments import styles

@api_view(['post'])
@permission_classes([IsAuthenticated])
@authentication_classes([TokenAuthentication])
def Api_Code(request):
    user = request.user
    lang = request.POST['lang']
    file = request.FILES['file']
    mode = request.POST['mode']
    modes = Style.objects.filter(name=mode)
    DATA = {}
    if len(modes) == 0:
        return Response(status=404)
    else:
        html = Mode(file.read(),lang,modes[0])
        print(html)
        DATA['code'] = str(html)
    user = Client.objects.get(username=user)
    user.count_use += 1
    user.save()
    return Response(DATA)

# @api_view(['post'])
# def Api_Register(request):
#     username = request.POST['username']
#     password = request.POST['password']
#     email = request.POST['email']
#     user = Client.objects.create(username=username,email=email)
#     user.set_password(password)
#     user.save()
#     if "image" in request.FILES:
#         image = request.FILES['image']
#         user.img = request.FILES['image']
#         user.save()
#     token_key = str(Token.objects.create(user=user))
#     return Response({
#         "key":token_key,
#         "username":username,
#         "email":email,
#         "password":user.password,
#     })

# @api_view(['post'])
# def Api_Login(request):
#     username = request.POST['username']
#     password = request.POST['password']
#     try:
#         user = Client.objects.get(username=username)
#         check = user.check_password(str(password))
#         print(check)
#         if check:
#             token_key = str(Token.objects.get(user=user))
#             return Response({
#             "key":token_key,
#             "username":username,
#             "email":email,
#             "password":user.password,
#             })
#         else:
#             return Response(status=401)
#     except Exception as error:
#         return Response(status=401)

@api_view(['get'])
def Api_Language(request):

    return Response(LoaderLanguage(Language.objects.all(),many=True).data)

@api_view(['get'])
def Api_Style(request):

    return Response(LoaderStyle(Style.objects.all(),many=True).data)

@api_view(['get'])
@permission_classes([IsAuthenticated,])
@authentication_classes([TokenAuthentication])
def View_Payment(request):
    return Response(LoaderPayment(Payment.objects.filter(user=request.user),many=True).data)
