from rest_framework.serializers import ModelSerializer
from .models import *

class LoaderLanguage(ModelSerializer):
	class Meta:
		model = Language
		fields = "__all__"

class LoaderStyle(ModelSerializer):
	class Meta:
		model = Style
		fields = "__all__"

class LoaderContactUs(ModelSerializer):
	class Meta:
		model = ContactUs
		fields = "__all__"

class LoaderPayment(ModelSerializer):
	class Meta:
		model = Payment
		fields = '__all__'
